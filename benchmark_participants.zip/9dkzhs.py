from typing import Dict, List

def calculate_batches(context_size: int, file_sizes: Dict[str, int], overhead_tokens: int = 0) -> List[List[str]]:
    items = sorted(file_sizes.items(), key=lambda x: x[1])
    n = len(items)
    uncovered = {(items[i][0], items[j][0]) for i in range(n) for j in range(i+1, n)}
    batches = []

    while uncovered:
        batch = []
        used = overhead_tokens
        for name, size in items:
            if used + size <= context_size:
                batch.append(name)
                used += size
        if not batch:
            break
        batches.append(batch)
        for i in range(len(batch)):
            for j in range(i+1, len(batch)):
                a, b = batch[i], batch[j]
                uncovered.discard((a, b))
                uncovered.discard((b, a))
        items = [x for x in items if x[0] not in batch]

    return batches