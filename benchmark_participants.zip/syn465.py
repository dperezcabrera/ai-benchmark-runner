from typing import Dict, List
import itertools

def calculate_batches(context_size: int, file_sizes: Dict[str, int], overhead_tokens: int = 0) -> List[List[str]]:
    filenames = sorted(file_sizes.keys())
    n = len(filenames)
    batches = []
    covered_pairs = set()
    
    all_pairs = set()
    for i in range(n):
        for j in range(i + 1, n):
            all_pairs.add((filenames[i], filenames[j]))
    
    while len(covered_pairs) < len(all_pairs):
        best_batch = None
        best_new_coverage = -1
        best_efficiency = float('-inf')
        
        for size in range(2, min(n, context_size) + 1):
            for candidate_files in itertools.combinations(filenames, size):
                total_tokens = sum(file_sizes[f] for f in candidate_files) + overhead_tokens
                if total_tokens > context_size:
                    continue
                
                new_pairs = set()
                for i in range(len(candidate_files)):
                    for j in range(i + 1, len(candidate_files)):
                        pair = tuple(sorted([candidate_files[i], candidate_files[j]]))
                        if pair not in covered_pairs:
                            new_pairs.add(pair)
                
                if not new_pairs:
                    continue
                
                new_coverage = len(new_pairs)
                efficiency = new_coverage / total_tokens
                
                if (new_coverage > best_new_coverage or 
                    (new_coverage == best_new_coverage and efficiency > best_efficiency)):
                    best_new_coverage = new_coverage
                    best_efficiency = efficiency
                    best_batch = list(candidate_files)
        
        if best_batch is None:
            break
            
        batches.append(best_batch)
        for i in range(len(best_batch)):
            for j in range(i + 1, len(best_batch)):
                pair = tuple(sorted([best_batch[i], best_batch[j]]))
                covered_pairs.add(pair)
    
    return batches