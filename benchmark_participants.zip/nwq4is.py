from typing import Dict, List, Set

def calculate_batches(context_size: int, file_sizes: Dict[str, int], overhead_tokens: int = 0) -> List[List[str]]:
    if context_size <= 0:
        raise ValueError("context_size must be positive")
    
    if overhead_tokens < 0:
        raise ValueError("overhead_tokens must be non-negative")

    effective_limit = context_size - overhead_tokens
    
    if effective_limit <= 0:
        raise ValueError("overhead_tokens must be less than context_size")

    if not file_sizes:
        return []

    paths = list(file_sizes.keys())
    sizes = list(file_sizes.values())
    n = len(paths)
    
    max_allowed = context_size // 4
    if any(s > max_allowed for s in sizes):
         raise ValueError("File exceeds 1/4 context limit")

    adj = [set() for _ in range(n)]
    degrees = [0] * n
    total_edges = 0
    
    for i in range(n):
        for j in range(i + 1, n):
            adj[i].add(j)
            adj[j].add(i)
            degrees[i] += 1
            degrees[j] += 1
            total_edges += 1

    batches_indices = []
    active_nodes = set(range(n))

    while total_edges > 0:
        best_seed = -1
        max_score = -1.0
        
        candidates = [i for i in active_nodes if degrees[i] > 0]
        if not candidates:
            break

        for i in candidates:
            score = degrees[i] / sizes[i]
            if score > max_score:
                max_score = score
                best_seed = i
        
        if sizes[best_seed] > effective_limit:
             break

        current_batch = [best_seed]
        current_batch_set = {best_seed}
        current_size = sizes[best_seed]
        
        while True:
            best_cand = -1
            best_cand_val = -1.0
            remaining = effective_limit - current_size
            found = False
            
            for i in candidates:
                if i in current_batch_set:
                    continue
                
                s_i = sizes[i]
                if s_i > remaining:
                    continue
                
                new_edges = 0
                for member in current_batch:
                    if member in adj[i]:
                        new_edges += 1
                
                if new_edges > 0:
                    val = new_edges / s_i
                    if val > best_cand_val:
                        best_cand_val = val
                        best_cand = i
                        found = True
            
            if found:
                current_batch.append(best_cand)
                current_batch_set.add(best_cand)
                current_size += sizes[best_cand]
            else:
                break
        
        m = len(current_batch)
        edges_removed = 0
        for i in range(m):
            u = current_batch[i]
            for j in range(i + 1, m):
                v = current_batch[j]
                if v in adj[u]:
                    adj[u].remove(v)
                    adj[v].remove(u)
                    degrees[u] -= 1
                    degrees[v] -= 1
                    total_edges -= 1
                    edges_removed += 1
        
        if edges_removed == 0:
             u = candidates[0]
             if adj[u]:
                 v = next(iter(adj[u]))
                 if sizes[u] + sizes[v] <= effective_limit:
                     current_batch = [u, v]
                     adj[u].remove(v)
                     adj[v].remove(u)
                     degrees[u] -= 1
                     degrees[v] -= 1
                     total_edges -= 1
                 else:
                     break 
        
        batches_indices.append(current_batch)

    batch_loads = []
    for b in batches_indices:
        load = sum(sizes[i] for i in b)
        batch_loads.append((load, b))
    
    batch_loads.sort(key=lambda x: x[0])
    
    final_merged_batches = []
    skip_indices = set()
    
    for i in range(len(batch_loads)):
        if i in skip_indices: continue
        
        load_i, batch_i = batch_loads[i]
        merged = False
        
        for j in range(len(batch_loads) - 1, i, -1):
            if j in skip_indices: continue
            
            load_j, batch_j = batch_loads[j]
            
            if load_i + load_j <= effective_limit:
                batch_loads[j] = (load_i + load_j, batch_j + batch_i)
                skip_indices.add(i)
                merged = True
                break
        
        if not merged:
            final_merged_batches.append(batch_i)

    for j in range(len(batch_loads)):
         if j not in skip_indices and batch_loads[j][1] not in final_merged_batches:
             final_merged_batches.append(batch_loads[j][1])

    return [[paths[i] for i in b_idxs] for b_idxs in final_merged_batches]