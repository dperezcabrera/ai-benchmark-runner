from typing import Dict, List, Set, Tuple

def calculate_batches(
    context_size: int, 
    file_sizes: Dict[str, int], 
    overhead_tokens: int = 0
) -> List[List[str]]:
    """
    Greedy implementation to ensure pairwise coverage while minimizing token cost.
    
    Strategy:
    1. Track all pairs that need to be covered
    2. Greedily build batches that cover the most uncovered pairs
    3. Pack as many files as possible into each batch (respecting token limit)
    """
    filenames = sorted(file_sizes.keys())  # Sort for determinism
    n = len(filenames)
    
    # Handle edge cases
    if n == 0:
        return []
    if n == 1:
        return [[filenames[0]]]
    
    # Generate all pairs that need coverage
    uncovered_pairs: Set[Tuple[str, str]] = set()
    for i in range(n):
        for j in range(i + 1, n):
            uncovered_pairs.add((filenames[i], filenames[j]))
    
    batches = []
    
    while uncovered_pairs:
        # Greedy: try to find the batch that covers the most uncovered pairs
        best_batch = None
        best_covered = set()
        
        # Start with the file involved in the most uncovered pairs
        file_pair_counts = {}
        for f1, f2 in uncovered_pairs:
            file_pair_counts[f1] = file_pair_counts.get(f1, 0) + 1
            file_pair_counts[f2] = file_pair_counts.get(f2, 0) + 1
        
        # Sort files by how many uncovered pairs they're in (descending)
        sorted_files = sorted(file_pair_counts.keys(), 
                            key=lambda f: file_pair_counts[f], 
                            reverse=True)
        
        # Build batch greedily: start with most needed file, add files that maximize coverage
        current_batch = []
        current_size = overhead_tokens
        
        for seed_file in sorted_files[:min(5, len(sorted_files))]:  # Try top candidates as seed
            candidate_batch = [seed_file]
            candidate_size = overhead_tokens + file_sizes[seed_file]
            
            # Add files that fit and maximize new pair coverage
            remaining_files = [f for f in sorted_files if f != seed_file]
            
            for file in remaining_files:
                new_size = candidate_size + file_sizes[file]
                if new_size <= context_size:
                    candidate_batch.append(file)
                    candidate_size = new_size
            
            # Calculate how many uncovered pairs this batch covers
            candidate_covered = set()
            for i in range(len(candidate_batch)):
                for j in range(i + 1, len(candidate_batch)):
                    pair = tuple(sorted([candidate_batch[i], candidate_batch[j]]))
                    if pair in uncovered_pairs:
                        candidate_covered.add(pair)
            
            # Keep the best batch
            if len(candidate_covered) > len(best_covered):
                best_batch = candidate_batch
                best_covered = candidate_covered
        
        # Add the best batch found
        if best_batch:
            batches.append(best_batch)
            uncovered_pairs -= best_covered
        else:
            # Fallback: create minimal batch with two files that need coverage
            if uncovered_pairs:
                pair = next(iter(uncovered_pairs))
                batches.append(list(pair))
                uncovered_pairs.discard(pair)
    
    return batches