from typing import Dict, List
import itertools

def calculate_batches(context_size: int, file_sizes: Dict[str, int], overhead_tokens: int = 0) -> List[List[str]]:
    sorted_files = sorted(file_sizes.keys())
    needed_pairs = set(itertools.combinations(sorted_files, 2))
    batches = []

    while needed_pairs:
        seed_pair = max(needed_pairs, key=lambda p: file_sizes[p[0]] + file_sizes[p[1]])
        
        current_batch = list(seed_pair)
        current_usage = file_sizes[seed_pair[0]] + file_sizes[seed_pair[1]] + overhead_tokens
        batch_set = set(current_batch)
        
        candidates = [f for f in sorted_files if f not in batch_set]
        
        while True:
            best_cand = None
            best_score = -1
            
            for cand in candidates:
                size = file_sizes[cand]
                if current_usage + size <= context_size:
                    score = 0
                    for existing in batch_set:
                        p = tuple(sorted((cand, existing)))
                        if p in needed_pairs:
                            score += 1
                    
                    if score > best_score:
                        best_score = score
                        best_cand = cand
                    elif score == best_score and best_cand:
                        if size > file_sizes[best_cand]:
                            best_cand = cand

            if best_cand and best_score > 0:
                current_batch.append(best_cand)
                batch_set.add(best_cand)
                current_usage += file_sizes[best_cand]
                candidates.remove(best_cand)
            else:
                break
        
        batches.append(current_batch)
        
        for p in itertools.combinations(current_batch, 2):
            p_sorted = tuple(sorted(p))
            if p_sorted in needed_pairs:
                needed_pairs.remove(p_sorted)
                
    return batches