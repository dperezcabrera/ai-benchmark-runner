from typing import Dict, List
import itertools

def calculate_batches(context_size: int, file_sizes: Dict[str, int], overhead_tokens: int = 0) -> List[List[str]]:
    filenames = list(file_sizes.keys())
    batches = []
    pairs = list(itertools.combinations(filenames, 2))
    
    while pairs:
        batch = []
        remaining_tokens = context_size - overhead_tokens
        for pair in pairs[:]:
            file1, file2 = pair
            total_tokens = file_sizes[file1] + file_sizes[file2]
            if total_tokens <= remaining_tokens:
                if file1 not in batch:
                    batch.append(file1)
                    remaining_tokens -= file_sizes[file1]
                if file2 not in batch:
                    batch.append(file2)
                    remaining_tokens -= file_sizes[file2]
                pairs.remove(pair)
        if not batch:
            batch.append(pairs[0][0])
            pairs.remove((pairs[0][0], pairs[0][1]))
        batches.append(batch)
    
    return batches
