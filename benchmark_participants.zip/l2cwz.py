```python
from typing import Dict, List
import itertools

def calculate_batches(context_size: int, file_sizes: Dict[str, int], overhead_tokens: int = 0) -> List[List[str]]:
    filenames = list(file_sizes)
    if any(file_sizes[f] + overhead_tokens > context_size for f in filenames):
        raise ValueError("A single file exceeds the context size limit.")
    for a, b in itertools.combinations(filenames, 2):
        if file_sizes[a] + file_sizes[b] + overhead_tokens > context_size:
            raise ValueError("At least one required pair cannot fit within the context size.")
    uncovered_pairs = set(tuple(sorted(pair)) for pair in itertools.combinations(filenames, 2))
    small_first = sorted(filenames, key=lambda x: (file_sizes[x], x))
    batches = []
    while uncovered_pairs:
        pair = max(uncovered_pairs, key=lambda p: (file_sizes[p[0]] + file_sizes[p[1]], p))
        batch = set(pair)
        token_sum = file_sizes[pair[0]] + file_sizes[pair[1]] + overhead_tokens
        for f in small_first:
            if f in batch:
                continue
            size = file_sizes[f]
            if token_sum + size <= context_size:
                batch.add(f)
                token_sum += size
        batch_list = sorted(batch)
        batches.append(batch_list)
        for a, b in itertools.combinations(batch_list, 2):
            uncovered_pairs.discard((a, b))
    return batches
```