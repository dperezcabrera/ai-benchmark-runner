from typing import Dict, List, Set, Tuple
import itertools

def calculate_batches(
    context_size: int,
    file_sizes: Dict[str, int],
    overhead_tokens: int = 0
) -> List[List[str]]:
    files = sorted(file_sizes.keys())
    n = len(files)
    if n <= 1:
        return []
    effective_capacity = context_size - overhead_tokens
    if effective_capacity <= 0:
        raise ValueError
    for f in files:
        if file_sizes[f] > effective_capacity:
            raise ValueError
    for i in range(n):
        for j in range(i + 1, n):
            if file_sizes[files[i]] + file_sizes[files[j]] > effective_capacity:
                raise ValueError
    uncovered_pairs: Set[Tuple[str, str]] = {
        (files[i], files[j])
        for i in range(n)
        for j in range(i + 1, n)
    }
    batches: List[List[str]] = []
    while uncovered_pairs:
        pair_counts = {f: 0 for f in files}
        for a, b in uncovered_pairs:
            pair_counts[a] += 1
            pair_counts[b] += 1
        seed = max(files, key=lambda f: (pair_counts[f], -len(f), f))
        current_batch = {seed}
        remaining_capacity = effective_capacity - file_sizes[seed]
        while True:
            best_candidate = None
            best_gain = 0
            for f in files:
                if f in current_batch:
                    continue
                if file_sizes[f] > remaining_capacity:
                    continue
                gain = 0
                for g in current_batch:
                    pair = (g, f) if g < f else (f, g)
                    if pair in uncovered_pairs:
                        gain += 1
                if gain > best_gain:
                    best_gain = gain
                    best_candidate = f
                elif gain == best_gain and gain > 0 and best_candidate is not None:
                    if (file_sizes[f], f) > (file_sizes[best_candidate], best_candidate):
                        best_candidate = f
            if best_candidate is None or best_gain == 0:
                break
            current_batch.add(best_candidate)
            remaining_capacity -= file_sizes[best_candidate]
        batch_list = sorted(current_batch)
        batches.append(batch_list)
        for a, b in itertools.combinations(batch_list, 2):
            pair = (a, b) if a < b else (b, a)
            if pair in uncovered_pairs:
                uncovered_pairs.remove(pair)
    return batches
