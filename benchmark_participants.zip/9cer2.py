from typing import Dict, List
import itertools

def calculate_batches(context_size: int, file_sizes: Dict[str, int], overhead_tokens: int = 0) -> List[List[str]]:
    filenames = list(file_sizes.keys())
    if not filenames:
        return []
    
    covered_pairs = set()
    all_pairs = set(itertools.combinations(filenames, 2))
    batches = []
    
    sorted_files = sorted(filenames, key=lambda x: file_sizes[x], reverse=True)
    
    while len(covered_pairs) < len(all_pairs):
        current_batch = []
        current_size = overhead_tokens
        
        for file in sorted_files:
            if file in current_batch:
                continue
            new_size = current_size + file_sizes[file]
            if new_size <= context_size:
                current_batch.append(file)
                current_size = new_size
        
        if not current_batch:
            raise ValueError("No valid batch can be formed; a single file exceeds context size.")
        
        batch_pairs = set(itertools.combinations(current_batch, 2))
        covered_pairs.update(batch_pairs)
        batches.append(current_batch)
        
        remaining_pairs = all_pairs - covered_pairs
        if not remaining_pairs:
            break
            
        involved_files = set()
        for pair in remaining_pairs:
            involved_files.update(pair)
        
        sorted_files = sorted(involved_files, key=lambda x: file_sizes[x], reverse=True)
    
    return batches